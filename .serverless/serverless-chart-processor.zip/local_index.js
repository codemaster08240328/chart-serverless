const server = require('./app');

server.listen(3000, () => {
    console.log('listening on 3000')
})